#!/usr/bin/env bash
# =============================================================================
# Oracle Data Migration — runner script
#
# Usage:
#   ./scripts/run_migration.sh [python -m src.main arguments]
#
# Examples:
#   ./scripts/run_migration.sh
#   ./scripts/run_migration.sh --instance instance1
#   ./scripts/run_migration.sh --force-reload
#   ./scripts/run_migration.sh --report-only
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV_DIR="$PROJECT_DIR/.venv"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

log()   { echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $*"; }
warn()  { echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARN${NC}  $*"; }
error() { echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR${NC} $*" >&2; }

# ── Virtual environment ───────────────────────────────────────────────────────
if [[ -d "$VENV_DIR" ]]; then
    # shellcheck disable=SC1091
    source "$VENV_DIR/bin/activate"
    log "Virtual environment activated: $VENV_DIR"
else
    warn "No virtual environment at $VENV_DIR"
    warn "Create one with:  python -m venv .venv && .venv/bin/pip install -r requirements.txt"
fi

# ── Run ───────────────────────────────────────────────────────────────────────
log "Starting migration from: $PROJECT_DIR"
cd "$PROJECT_DIR"

python -m src.main "$@"
EXIT_CODE=$?

if [[ $EXIT_CODE -eq 0 ]]; then
    log "Migration finished successfully (exit 0)"
elif [[ $EXIT_CODE -eq 130 ]]; then
    warn "Migration interrupted by user (Ctrl-C)"
else
    error "Migration failed (exit $EXIT_CODE)"
fi

exit $EXIT_CODE
