#!/usr/bin/env python3
"""
One-time utility: encrypt a database password for storage in config.ini.

Run once before your first migration:
    python scripts/encrypt_password.py

The script will:
  1. Generate a new Fernet key if none exists  (~/.migration_key)
  2. Prompt for the database password (hidden input)
  3. Print the encrypted value → paste it into config.ini
"""

import getpass
import sys
from pathlib import Path

# Allow running from project root
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.crypto_manager import CryptoManager, KEY_FILE, KEY_ENV_VAR


def main():
    print("Oracle Data Migration — Password Encryption Utility")
    print("=" * 52)

    crypto = CryptoManager()

    # ── Key setup ────────────────────────────────────────────────────────────
    if not KEY_FILE.exists():
        print(f"\nNo encryption key found at {KEY_FILE}")
        choice = input("Generate a new key? [Y/n]: ").strip().lower()
        if choice not in ("", "y", "yes"):
            print("Aborted.")
            sys.exit(1)

        new_key = CryptoManager.generate_key()
        KEY_FILE.write_text(new_key)
        KEY_FILE.chmod(0o600)        # owner-read-only

        print(f"\nKey saved to:  {KEY_FILE}  (permissions: 600)")
        print("IMPORTANT: Back this file up securely!")
        print(
            f"Alternative:  export {KEY_ENV_VAR}={new_key!r}  "
            f"(put in ~/.bashrc / systemd unit / vault)"
        )
    else:
        print(f"\nUsing existing key from: {KEY_FILE}")

    # ── Password input ───────────────────────────────────────────────────────
    print()
    pw  = getpass.getpass("Enter database password to encrypt: ")
    pw2 = getpass.getpass("Confirm password:                  ")
    if pw != pw2:
        print("\nPasswords do not match. Aborted.")
        sys.exit(1)

    encrypted = crypto.encrypt(pw)

    # ── Verify round-trip ────────────────────────────────────────────────────
    decrypted = crypto.decrypt(encrypted)
    if decrypted != pw:
        print("\nERROR: Round-trip verification failed. Do NOT use this value.")
        sys.exit(1)

    print("\n" + "=" * 52)
    print("Paste this line into  config/config.ini  under [database]:")
    print()
    print(f"password_encrypted = {encrypted}")
    print()
    print("Verification: OK")


if __name__ == "__main__":
    main()
