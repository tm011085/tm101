@echo off
:: =============================================================================
:: Oracle Data Migration — Windows runner script
::
:: Usage:
::   scripts\run_migration.bat [python -m src.main arguments]
::
:: Examples:
::   scripts\run_migration.bat
::   scripts\run_migration.bat --instance instance1
::   scripts\run_migration.bat --force-reload
::   scripts\run_migration.bat --report-only
::   scripts\run_migration.bat --instance instance1 --category case
::   scripts\run_migration.bat --validate-config
::
:: Requirements:
::   Python 3.10+  on PATH  (or adjust PYTHON_EXE below)
::   Virtual environment at  .venv\  in the project root (recommended)
:: =============================================================================
setlocal EnableDelayedExpansion

:: ── Paths ────────────────────────────────────────────────────────────────────
:: Derive project root from the location of this script
set "SCRIPT_DIR=%~dp0"
:: Remove trailing backslash
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
for %%D in ("%SCRIPT_DIR%") do set "PROJECT_DIR=%%~dpD"
:: Remove trailing backslash
set "PROJECT_DIR=%PROJECT_DIR:~0,-1%"

set "VENV_DIR=%PROJECT_DIR%\.venv"
set "VENV_PYTHON=%VENV_DIR%\Scripts\python.exe"
set "VENV_ACTIVATE=%VENV_DIR%\Scripts\activate.bat"

:: ── Timestamp helper (used in log lines) ─────────────────────────────────────
:: Format: YYYY-MM-DD HH:MM:SS
for /f "tokens=1-3 delims=/" %%a in ("%DATE%") do (
    set "LOG_DATE=%%c-%%a-%%b"
)
for /f "tokens=1-3 delims=:. " %%a in ("%TIME: =0%") do (
    set "LOG_TIME=%%a:%%b:%%c"
)
set "LOG_TS=%LOG_DATE% %LOG_TIME%"

:: ── Virtual environment ───────────────────────────────────────────────────────
if exist "%VENV_ACTIVATE%" (
    call "%VENV_ACTIVATE%"
    echo [%LOG_TS%] Virtual environment activated: %VENV_DIR%
    set "PYTHON_EXE=python"
) else (
    echo [%LOG_TS%] WARN  No virtual environment found at %VENV_DIR%
    echo [%LOG_TS%] WARN  Create one with:
    echo             cd /d "%PROJECT_DIR%"
    echo             python -m venv .venv
    echo             .venv\Scripts\pip install -r requirements.txt
    echo.
    :: Fall back to system Python
    set "PYTHON_EXE=python"
)

:: ── Verify Python is available ────────────────────────────────────────────────
where %PYTHON_EXE% >nul 2>&1
if errorlevel 1 (
    echo [%LOG_TS%] ERROR Python not found on PATH. Install Python 3.10+ and retry.
    exit /b 1
)

:: ── Change to project root and run ───────────────────────────────────────────
echo [%LOG_TS%] Starting migration from: %PROJECT_DIR%
cd /d "%PROJECT_DIR%"

%PYTHON_EXE% -m src.main %*
set "EXIT_CODE=%ERRORLEVEL%"

:: ── Result reporting ─────────────────────────────────────────────────────────
for /f "tokens=1-3 delims=/" %%a in ("%DATE%") do set "LOG_DATE=%%c-%%a-%%b"
for /f "tokens=1-3 delims=:. " %%a in ("%TIME: =0%") do set "LOG_TIME=%%a:%%b:%%c"
set "LOG_TS=%LOG_DATE% %LOG_TIME%"

if "%EXIT_CODE%"=="0" (
    echo [%LOG_TS%] Migration finished successfully.
) else if "%EXIT_CODE%"=="130" (
    echo [%LOG_TS%] WARN  Migration interrupted by user ^(Ctrl-C^).
) else (
    echo [%LOG_TS%] ERROR Migration failed with exit code %EXIT_CODE%.
)

endlocal
exit /b %EXIT_CODE%
