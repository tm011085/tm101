# Oracle Data Migration Tool

Streams pipe-delimited flat files (one per category, one folder per instance)
into Oracle tables with automatic DDL creation, resume-on-failure, and
per-file reconciliation metrics.

---

## Project structure

```
DataMigration/
├── config/
│   └── config.ini          ← all configuration (edit this first)
├── src/
│   ├── main.py             ← entry point
│   ├── config_manager.py   ← typed config access + password decryption
│   ├── crypto_manager.py   ← Fernet encryption / decryption
│   ├── db_manager.py       ← Oracle connection pool (python-oracledb)
│   ├── table_manager.py    ← DDL generation + table creation
│   ├── file_parser.py      ← streaming multi-line pipe-delimited parser
│   ├── progress_tracker.py ← MIG_LOAD_PROGRESS table management
│   ├── reconciliation.py   ← MIG_RECON_METRICS table + summary report
│   └── data_loader.py      ← orchestrator: discover → parse → insert
├── scripts/
│   ├── encrypt_password.py ← one-time password encryption utility
│   └── run_migration.sh    ← convenience wrapper
├── bad_records/            ← auto-created; unparseable rows written here
├── logs/                   ← auto-created; rotating log files
└── requirements.txt
```

---

## Quick start

### 1. Install dependencies

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Encrypt the database password

```bash
python scripts/encrypt_password.py
```

Follow the prompts. Copy the printed `password_encrypted = …` line into
`config/config.ini`.

The encryption key is saved to `~/.migration_key` (chmod 600).
Alternatively set the `MIGRATION_CRYPTO_KEY` environment variable.

### 3. Edit config/config.ini

At minimum update:

| Section | Key | Description |
|---------|-----|-------------|
| `[database]` | `host`, `port`, `service_name`, `username` | Oracle connection |
| `[database]` | `password_encrypted` | Output of step 2 |
| `[files]` | `base_directory` | Root folder containing instance sub-folders |
| `[files]` | `bad_records_directory` | Where to write unparseable rows |
| `[tables]` | `prefix` / `suffix` | e.g. `MIG_` makes table `MIG_CASE` |

### 4. Arrange your data

```
/data/migration/input/
├── instance1/
│   ├── case.dat
│   └── case_cust.dat
└── instance2/
    ├── case.dat
    ├── alert.dat
    └── alert_cust.dat
```

The **folder name** becomes `INSTANCE_NAME`; the **file stem** determines
which table to insert into.

### 5. Run

```bash
# Full migration
python -m src.main

# Or via the shell wrapper
./scripts/run_migration.sh

# Specific instance only
python -m src.main --instance instance1

# Specific instance + category
python -m src.main --instance instance1 --category case

# Force reload even if already completed
python -m src.main --force-reload

# Reconciliation report only (no loading)
python -m src.main --report-only

# Validate config then exit
python -m src.main --validate-config
```

---

## File format requirements

| Property | Value |
|----------|-------|
| Delimiter | `|` (pipe, configurable) |
| Quote character | **none** |
| Line terminator | LF (`\n`) |
| Header row | **yes** (first line) |
| Multi-line records | supported — embedded LF inside a field is OK |
| Pipe in data | treated as bad record (ambiguous without quoting) |
| Encoding | UTF-8 (configurable); BOM stripped automatically |

### Multi-line algorithm

A record is complete when the accumulated text contains exactly
`(num_columns − 1)` pipes.  Lines are appended until that count is reached.
If the count exceeds that value the record is written to the bad-record file.
If `max_continuation_lines` is exceeded without a complete record, it is also
rejected.

---

## Tables created

### Data tables  (one per category)

```sql
CREATE TABLE MIG_CASE (
    -- one column per header field:
    CASE_ID       VARCHAR2(4000),
    CASE_TEXT     CLOB,           -- ← "text" keyword triggers CLOB
    NARRATIVE     CLOB,           -- ← "narrative" keyword
    STATUS        VARCHAR2(4000),
    -- ... all other fields ...

    -- audit columns appended automatically:
    INSTANCE_NAME   VARCHAR2(500),
    FILE_LOADED     VARCHAR2(4000),
    LOAD_TIMESTAMP  TIMESTAMP DEFAULT SYSTIMESTAMP,
    LOAD_ID         NUMBER
);
```

**Column type rules**

| Column name contains (case-insensitive) | Oracle type |
|-----------------------------------------|-------------|
| `narrative`, `description`, `text`, `note`, `comment`, `remarks`, `detail`, `memo`, `body`, `content` | `CLOB` |
| anything else | `VARCHAR2(4000)` |

Keywords are configurable via `[columns] clob_keywords` in config.ini.

### Metadata tables

| Table | Purpose |
|-------|---------|
| `MIG_LOAD_PROGRESS` | One row per file load attempt; tracks status, counts, timing |
| `MIG_RECON_METRICS` | One row per completed file; source vs loaded vs bad counts |

---

## Resume on failure

If the process is killed or crashes mid-load:

1. On the next run, `reset_stale_loads()` marks any `IN_PROGRESS` rows as `FAILED`.
2. For each `FAILED` (or `COMPLETED` with `force_reload=true`) file:
   - All rows with that `LOAD_ID` are deleted from the target table.
   - The file is reloaded from scratch.

This ensures no partial data is left behind.

---

## Bad records

For each file load, a bad-record file is created in `bad_records_directory`:

```
bad_records/
└── instance1_case_42_bad.txt
```

Format:
```
PARSE_ERROR
<raw accumulated text that could not be parsed>
---END---

INSERT_ERROR|row_offset=N|ORA-XXXXX: ...
```

---

## Performance tuning

| Config key | Default | Notes |
|------------|---------|-------|
| `batch_size` | 10 000 | Rows per `executemany` call |
| `commit_interval` | 100 000 | Rows between commits |
| `pool_min` / `pool_max` | 2 / 10 | Connection pool |
| `max_continuation_lines` | 50 | Multi-line record limit |
| `parallel_workers` | 1 | >1 enables ThreadPoolExecutor (future) |

For millions of rows, `batch_size=10000` and `commit_interval=100000` are
good starting points.  Increase `pool_max` if running multiple instances in
parallel.

---

## Security notes

- Passwords are **never stored in plain text**.  The Fernet key lives at
  `~/.migration_key` (readable only by the OS user) or in an environment
  variable.
- Add `~/.migration_key` and `config/credentials.enc` to your secrets manager
  (HashiCorp Vault, AWS Secrets Manager, etc.) in production.
- The `.gitignore` excludes key files and log directories.

---

## Dependency versions

| Package | Purpose |
|---------|---------|
| `python-oracledb >= 2` | Oracle driver (thin mode — no Oracle Client needed) |
| `cryptography >= 41` | Fernet symmetric encryption |
| `pandas >= 2` | In-memory batch processing helpers |
| `numpy >= 1.24` | pandas dependency |
