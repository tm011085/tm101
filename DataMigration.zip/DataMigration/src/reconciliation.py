"""
Records per-file reconciliation metrics in MIG_RECON_METRICS and
provides a tabular summary report.

MATCH_STATUS values
-------------------
  MATCH    — source_count == loaded_count + bad_count
  MISMATCH — counts differ (investigate)
  SKIPPED  — file was already COMPLETED and not force-reloaded
"""

import logging
from typing import Optional

from .config_manager import ConfigManager
from .db_manager import DBManager

logger = logging.getLogger("migration.recon")


class ReconciliationManager:
    def __init__(self, config: ConfigManager, db: DBManager):
        self._config = config
        self._db     = db
        self._table  = config.recon_table

    # ------------------------------------------------------------------
    # DDL
    # ------------------------------------------------------------------

    def create_table(self, conn=None):
        if self._db.table_exists(self._table, conn):
            return
        ddl = f"""
        CREATE TABLE {self._table} (
            RECON_ID        NUMBER         GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            LOAD_ID         NUMBER,
            INSTANCE_NAME   VARCHAR2(500),
            CATEGORY        VARCHAR2(200),
            FILE_NAME       VARCHAR2(500),
            FILE_PATH       VARCHAR2(4000),
            TARGET_TABLE    VARCHAR2(200),
            SOURCE_COUNT    NUMBER DEFAULT 0,
            LOADED_COUNT    NUMBER DEFAULT 0,
            BAD_COUNT       NUMBER DEFAULT 0,
            SKIP_COUNT      NUMBER DEFAULT 0,
            MATCH_STATUS    VARCHAR2(20),
            RECON_TIME      TIMESTAMP DEFAULT SYSTIMESTAMP,
            NOTES           VARCHAR2(4000)
        )"""
        self._db.execute_ddl(ddl.strip(), conn)
        logger.info("Created reconciliation table: %s", self._table)

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------

    def record(
        self,
        *,
        load_id: int,
        instance_name: str,
        category: str,
        file_path: str,
        file_name: str,
        target_table: str,
        source_count: int,
        loaded_count: int,
        bad_count: int,
        skip_count: int = 0,
        notes: str = "",
        conn=None,
    ):
        match = "MATCH" if source_count == loaded_count + bad_count else "MISMATCH"
        sql = f"""
        INSERT INTO {self._table}
            (LOAD_ID, INSTANCE_NAME, CATEGORY, FILE_NAME, FILE_PATH,
             TARGET_TABLE, SOURCE_COUNT, LOADED_COUNT, BAD_COUNT,
             SKIP_COUNT, MATCH_STATUS, NOTES)
        VALUES
            (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11, :12)
        """
        params = [
            load_id, instance_name, category, file_name, file_path,
            target_table, source_count, loaded_count, bad_count,
            skip_count, match, notes[:4000],
        ]

        def _insert(c):
            cur = c.cursor()
            try:
                cur.execute(sql, params)
                c.commit()
            finally:
                cur.close()

        if conn:
            _insert(conn)
        else:
            with self._db.get_connection() as c:
                _insert(c)

        icon = "OK " if match == "MATCH" else "!!!"
        logger.info(
            "[%s] Recon %s/%s: source=%d loaded=%d bad=%d",
            icon, instance_name, category, source_count, loaded_count, bad_count,
        )

    def record_skipped(self, *, instance_name: str, category: str,
                       file_path: str, file_name: str, target_table: str, conn=None):
        self.record(
            load_id=0,
            instance_name=instance_name,
            category=category,
            file_path=file_path,
            file_name=file_name,
            target_table=target_table,
            source_count=0,
            loaded_count=0,
            bad_count=0,
            skip_count=1,
            notes="Skipped — already COMPLETED",
            conn=conn,
        )

    # ------------------------------------------------------------------
    # Reporting
    # ------------------------------------------------------------------

    def print_summary(self, load_id: Optional[int] = None):
        where = f"WHERE LOAD_ID = {load_id}" if load_id else ""
        sql = f"""
        SELECT INSTANCE_NAME, CATEGORY, FILE_NAME,
               SOURCE_COUNT, LOADED_COUNT, BAD_COUNT, MATCH_STATUS, RECON_TIME
        FROM   {self._table}
        {where}
        ORDER BY RECON_TIME
        """
        rows = self._db.execute_query(sql)
        sep = "=" * 100
        logger.info(sep)
        logger.info("RECONCILIATION SUMMARY")
        logger.info(sep)
        hdr = f"{'Instance':<22} {'Category':<18} {'File':<30} {'Source':>9} {'Loaded':>9} {'Bad':>7} {'Status':<10}"
        logger.info(hdr)
        logger.info("-" * 100)
        for r in rows:
            logger.info(
                f"{str(r[0]):<22} {str(r[1]):<18} {str(r[2]):<30} "
                f"{str(r[3]):>9} {str(r[4]):>9} {str(r[5]):>7} {str(r[6]):<10}"
            )
        logger.info(sep)
