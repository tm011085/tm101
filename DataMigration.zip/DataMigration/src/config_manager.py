"""
Loads and validates config/config.ini, decrypts passwords, and exposes
typed properties consumed by all other modules.
"""

import configparser
import logging
from pathlib import Path
from typing import List, Optional

from .crypto_manager import CryptoManager, CryptoError

logger = logging.getLogger("migration.config")

_DEFAULT_CONFIG = Path(__file__).parent.parent / "config" / "config.ini"


class ConfigError(Exception):
    pass


class ConfigManager:
    def __init__(self, config_path: Optional[Path] = None):
        self._path   = config_path or _DEFAULT_CONFIG
        self._cfg    = configparser.ConfigParser(interpolation=None)
        self._crypto = CryptoManager()
        self._pw: Optional[str] = None
        self._load()

    # ------------------------------------------------------------------
    # Loading / validation
    # ------------------------------------------------------------------

    def _load(self):
        if not self._path.exists():
            raise ConfigError(f"Config file not found: {self._path}")
        self._cfg.read(self._path, encoding="utf-8")
        logger.info("Configuration loaded from %s", self._path)
        self._validate()

    def _validate(self):
        required = {
            "database":         ["host", "port", "service_name", "username", "password_encrypted"],
            "connection_pool":  ["min_connections", "max_connections"],
            "tables":           ["prefix", "progress_table", "recon_table"],
            "files":            ["base_directory", "bad_records_directory", "separator"],
            "loading":          ["batch_size", "commit_interval"],
        }
        for section, keys in required.items():
            if not self._cfg.has_section(section):
                raise ConfigError(f"Missing config section: [{section}]")
            for key in keys:
                if not self._cfg.has_option(section, key):
                    raise ConfigError(f"Missing config key: [{section}] {key}")

        if not self._cfg.get("database", "password_encrypted", fallback="").strip():
            raise ConfigError(
                "password_encrypted is empty. Run scripts/encrypt_password.py "
                "and paste the result into config.ini."
            )

    # ------------------------------------------------------------------
    # Database
    # ------------------------------------------------------------------

    @property
    def db_host(self) -> str:
        return self._cfg.get("database", "host")

    @property
    def db_port(self) -> int:
        return self._cfg.getint("database", "port")

    @property
    def db_service_name(self) -> str:
        return self._cfg.get("database", "service_name")

    @property
    def db_username(self) -> str:
        return self._cfg.get("database", "username")

    @property
    def db_password(self) -> str:
        if self._pw is None:
            enc = self._cfg.get("database", "password_encrypted")
            try:
                self._pw = self._crypto.decrypt(enc)
            except CryptoError as exc:
                raise ConfigError(f"Cannot decrypt database password: {exc}") from exc
        return self._pw

    # ------------------------------------------------------------------
    # Connection pool
    # ------------------------------------------------------------------

    @property
    def pool_min(self) -> int:
        return self._cfg.getint("connection_pool", "min_connections", fallback=2)

    @property
    def pool_max(self) -> int:
        return self._cfg.getint("connection_pool", "max_connections", fallback=10)

    @property
    def pool_increment(self) -> int:
        return self._cfg.getint("connection_pool", "increment", fallback=1)

    @property
    def pool_timeout(self) -> int:
        return self._cfg.getint("connection_pool", "timeout", fallback=300)

    @property
    def pool_wait_timeout(self) -> int:
        return self._cfg.getint("connection_pool", "wait_timeout", fallback=10)

    # ------------------------------------------------------------------
    # Tables
    # ------------------------------------------------------------------

    @property
    def table_prefix(self) -> str:
        return self._cfg.get("tables", "prefix", fallback="")

    @property
    def table_suffix(self) -> str:
        return self._cfg.get("tables", "suffix", fallback="")

    @property
    def progress_table(self) -> str:
        return self._cfg.get("tables", "progress_table")

    @property
    def recon_table(self) -> str:
        return self._cfg.get("tables", "recon_table")

    def get_table_name(self, category: str) -> str:
        """Build the fully-qualified table name for a given category."""
        return f"{self.table_prefix}{category.upper()}{self.table_suffix}"

    # ------------------------------------------------------------------
    # Files
    # ------------------------------------------------------------------

    @property
    def base_directory(self) -> Path:
        return Path(self._cfg.get("files", "base_directory"))

    @property
    def bad_records_directory(self) -> Path:
        return Path(self._cfg.get("files", "bad_records_directory"))

    @property
    def file_pattern(self) -> str:
        return self._cfg.get("files", "file_pattern", fallback="*.dat")

    @property
    def separator(self) -> str:
        return self._cfg.get("files", "separator", fallback="|")

    @property
    def encoding(self) -> str:
        return self._cfg.get("files", "encoding", fallback="utf-8")

    @property
    def max_continuation_lines(self) -> int:
        return self._cfg.getint("files", "max_continuation_lines", fallback=50)

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    @property
    def batch_size(self) -> int:
        return self._cfg.getint("loading", "batch_size", fallback=10_000)

    @property
    def commit_interval(self) -> int:
        return self._cfg.getint("loading", "commit_interval", fallback=100_000)

    @property
    def max_retries(self) -> int:
        return self._cfg.getint("loading", "max_retries", fallback=3)

    @property
    def force_reload(self) -> bool:
        return self._cfg.getboolean("loading", "force_reload", fallback=False)

    @force_reload.setter
    def force_reload(self, value: bool):
        self._cfg.set("loading", "force_reload", str(value).lower())

    @property
    def parallel_workers(self) -> int:
        return self._cfg.getint("loading", "parallel_workers", fallback=1)

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------

    @property
    def log_directory(self) -> Path:
        return Path(self._cfg.get("logging", "log_directory", fallback="logs"))

    @property
    def log_level(self) -> str:
        return self._cfg.get("logging", "log_level", fallback="INFO")

    @property
    def log_max_bytes(self) -> int:
        mb = self._cfg.getint("logging", "max_file_size_mb", fallback=100)
        return mb * 1024 * 1024

    @property
    def log_backup_count(self) -> int:
        return self._cfg.getint("logging", "backup_count", fallback=10)

    # ------------------------------------------------------------------
    # Column typing
    # ------------------------------------------------------------------

    @property
    def clob_keywords(self) -> List[str]:
        raw = self._cfg.get(
            "columns", "clob_keywords",
            fallback="narrative,description,text,note,comment,remarks,detail,memo,body,content",
        )
        return [k.strip().lower() for k in raw.split(",") if k.strip()]

    @property
    def audit_instance_col(self) -> str:
        return self._cfg.get("columns", "audit_instance_col", fallback="INSTANCE_NAME")

    @property
    def audit_file_col(self) -> str:
        return self._cfg.get("columns", "audit_file_col", fallback="FILE_LOADED")

    @property
    def audit_timestamp_col(self) -> str:
        return self._cfg.get("columns", "audit_timestamp_col", fallback="LOAD_TIMESTAMP")

    @property
    def audit_load_id_col(self) -> str:
        return self._cfg.get("columns", "audit_load_id_col", fallback="LOAD_ID")

    @property
    def max_column_name_length(self) -> int:
        return self._cfg.getint("columns", "max_column_name_length", fallback=30)
