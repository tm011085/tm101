"""
Fernet-based symmetric encryption for database passwords stored in config.ini.

Key resolution order:
  1. Environment variable  MIGRATION_CRYPTO_KEY  (base64-encoded Fernet key)
  2. Key file              ~/.migration_key
"""

import os
import logging
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

logger = logging.getLogger("migration.crypto")

KEY_ENV_VAR = "MIGRATION_CRYPTO_KEY"
KEY_FILE    = Path.home() / ".migration_key"


class CryptoError(Exception):
    pass


class CryptoManager:
    def __init__(self):
        self._fernet = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_fernet(self) -> Fernet:
        if self._fernet is None:
            self._fernet = Fernet(self._load_key())
        return self._fernet

    def _load_key(self) -> bytes:
        value = os.environ.get(KEY_ENV_VAR)
        if value:
            logger.debug("Encryption key loaded from environment variable %s", KEY_ENV_VAR)
            return value.strip().encode()

        if KEY_FILE.exists():
            logger.debug("Encryption key loaded from %s", KEY_FILE)
            return KEY_FILE.read_bytes().strip()

        raise CryptoError(
            f"Encryption key not found. "
            f"Set the {KEY_ENV_VAR} environment variable, "
            f"or run scripts/encrypt_password.py to create {KEY_FILE}."
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def encrypt(self, plain_text: str) -> str:
        """Return the Fernet-encrypted, base64-encoded ciphertext."""
        return self._get_fernet().encrypt(plain_text.encode()).decode()

    def decrypt(self, encrypted_text: str) -> str:
        """Decrypt a Fernet ciphertext and return plain text."""
        try:
            return self._get_fernet().decrypt(encrypted_text.strip().encode()).decode()
        except InvalidToken as exc:
            raise CryptoError(
                "Password decryption failed — wrong key or corrupted ciphertext."
            ) from exc

    @staticmethod
    def generate_key() -> str:
        """Generate and return a new base64-encoded Fernet key."""
        return Fernet.generate_key().decode()
