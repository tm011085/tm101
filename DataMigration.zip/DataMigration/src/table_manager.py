"""
Derives Oracle DDL from file headers and ensures target tables exist.

Rules
-----
* All data columns → VARCHAR2(4000)
* Columns whose names contain any clob_keyword substring → CLOB
* Four audit columns are appended: INSTANCE_NAME, FILE_LOADED,
  LOAD_TIMESTAMP (DEFAULT SYSTIMESTAMP), LOAD_ID
* Column names are sanitised to valid Oracle identifiers and truncated
  to max_column_name_length characters.
* Duplicate sanitised names get a numeric suffix (_2, _3 …).
"""

import re
import logging
from typing import Dict, List, Set, Tuple

from .config_manager import ConfigManager
from .db_manager import DBManager

logger = logging.getLogger("migration.table")

# (sanitised_data_cols, clob_cols_set)
_SchemaEntry = Tuple[List[str], Set[str]]


class TableManager:
    def __init__(self, config: ConfigManager, db: DBManager):
        self._config = config
        self._db = db
        self._cache: Dict[str, _SchemaEntry] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_or_create_table(
        self,
        table_name: str,
        raw_headers: List[str],
        conn=None,
    ) -> _SchemaEntry:
        """
        Ensure *table_name* exists with the right columns.
        Returns (sanitised_data_cols, clob_cols_set).
        """
        if table_name in self._cache:
            return self._cache[table_name]

        data_cols, clob_set = self._derive_schema(raw_headers)

        if not self._db.table_exists(table_name, conn):
            ddl = self._build_ddl(table_name, data_cols, clob_set)
            logger.info("Creating table %s  (%d data columns)", table_name, len(data_cols))
            logger.debug("DDL:\n%s", ddl)
            self._db.execute_ddl(ddl, conn)
            self._create_indexes(table_name, conn)
        else:
            logger.info("Table %s already exists", table_name)

        self._cache[table_name] = (data_cols, clob_set)
        return data_cols, clob_set

    # ------------------------------------------------------------------
    # Schema derivation
    # ------------------------------------------------------------------

    def _derive_schema(self, raw_headers: List[str]) -> _SchemaEntry:
        data_cols: List[str] = []
        clob_set:  Set[str]  = set()
        seen: Dict[str, int] = {}

        for raw in raw_headers:
            col = self._sanitise(raw)
            if col in seen:
                seen[col] += 1
                col = f"{col}_{seen[col]}"
            else:
                seen[col] = 1

            data_cols.append(col)
            if self._is_clob(col):
                clob_set.add(col)

        return data_cols, clob_set

    def _sanitise(self, col: str) -> str:
        col = col.strip()
        col = re.sub(r"[^A-Za-z0-9_]", "_", col)
        col = re.sub(r"_+", "_", col).strip("_") or "COL"
        if col[0].isdigit():
            col = "COL_" + col
        return col[: self._config.max_column_name_length].upper()

    def _is_clob(self, col_name: str) -> bool:
        lower = col_name.lower()
        return any(kw in lower for kw in self._config.clob_keywords)

    # ------------------------------------------------------------------
    # DDL generation
    # ------------------------------------------------------------------

    def _build_ddl(self, table_name: str, data_cols: List[str], clob_set: Set[str]) -> str:
        lines: List[str] = []
        for col in data_cols:
            col_type = "CLOB" if col in clob_set else "VARCHAR2(4000)"
            lines.append(f"    {col} {col_type}")

        # Audit columns
        cfg = self._config
        lines += [
            f"    {cfg.audit_instance_col}  VARCHAR2(500)",
            f"    {cfg.audit_file_col}      VARCHAR2(4000)",
            f"    {cfg.audit_timestamp_col} TIMESTAMP DEFAULT SYSTIMESTAMP",
            f"    {cfg.audit_load_id_col}   NUMBER",
        ]
        return "CREATE TABLE {} (\n{}\n)".format(table_name, ",\n".join(lines))

    def _create_indexes(self, table_name: str, conn=None):
        cfg = self._config
        short = table_name[:20]
        indexes = [
            (
                f"IDX_{short}_LID",
                f"CREATE INDEX IDX_{short}_LID ON {table_name} ({cfg.audit_load_id_col})",
            ),
            (
                f"IDX_{short}_INST",
                f"CREATE INDEX IDX_{short}_INST ON {table_name} ({cfg.audit_instance_col})",
            ),
        ]
        for name, ddl in indexes:
            try:
                self._db.execute_ddl(ddl, conn)
                logger.debug("Created index %s", name)
            except Exception as exc:
                logger.warning("Could not create index %s: %s", name, exc)

    # ------------------------------------------------------------------
    # Utilities (exposed for testing / reporting)
    # ------------------------------------------------------------------

    def column_type(self, col_name: str) -> str:
        return "CLOB" if self._is_clob(col_name) else "VARCHAR2(4000)"

    def sanitise(self, col: str) -> str:
        return self._sanitise(col)
