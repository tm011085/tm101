"""Oracle Data Migration package."""
__version__ = "1.0.0"
