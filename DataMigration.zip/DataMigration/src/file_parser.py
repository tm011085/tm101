"""
Streaming parser for pipe-delimited flat files that may contain embedded
newlines (multi-line records) but no quote character.

Parsing contract
----------------
Each complete record contains exactly  (num_columns - 1)  pipe characters.

Line-accumulation algorithm
----------------------------
1. Read one raw line at a time (newline stripped).
2. Append to an in-progress buffer.
3. Count pipes in the accumulated text:
   * == expected → emit as GOOD record (split on pipe)
   * >  expected → emit as BAD  record (ambiguous — pipe appears in data)
   * <  expected → continue accumulating
4. If the buffer grows beyond max_continuation_lines without reaching the
   expected pipe count, emit as BAD and reset.

Bad records
-----------
Yielded as ('bad', raw_text_string).
The caller is responsible for writing them to a rejection file.

Performance
-----------
* Pure-Python generator — no memory proportional to file size.
* Works with files containing millions of records.
* BOM-safe: strips UTF-8 BOM from the first line if present.
"""

import logging
from pathlib import Path
from typing import Generator, List, Tuple

logger = logging.getLogger("migration.parser")

# ('good', [field, …]) | ('bad', raw_text)
ParseResult = Tuple[str, object]


class FileParser:
    def __init__(
        self,
        separator: str = "|",
        encoding: str = "utf-8",
        max_continuation_lines: int = 50,
    ):
        self._sep      = separator
        self._enc      = encoding
        self._max_cont = max_continuation_lines

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def read_headers(self, filepath: Path) -> List[str]:
        """Return the column names from the first line of *filepath*."""
        with open(filepath, "r", encoding=self._enc, newline="") as fh:
            line = fh.readline().rstrip("\r\n")
        if not line:
            raise ValueError(f"File is empty or has no header: {filepath}")
        line = line.lstrip("\ufeff")          # strip UTF-8 BOM if present
        return line.split(self._sep)

    def parse(self, filepath: Path) -> Generator[ParseResult, None, None]:
        """
        Yield ('good', [fields]) or ('bad', raw_text) for every record in
        *filepath* (skipping the header line).
        """
        headers = self.read_headers(filepath)
        num_cols = len(headers)
        expected_pipes = num_cols - 1

        logger.info(
            "Parsing %s — %d column(s), expecting %d pipe(s) per record",
            filepath.name, num_cols, expected_pipes,
        )

        buffer: List[str] = []
        file_line = 1   # header already consumed by read_headers

        with open(filepath, "r", encoding=self._enc, newline="") as fh:
            fh.readline()                      # skip header
            file_line += 1

            for raw in fh:
                file_line += 1
                line = raw.rstrip("\r\n")
                buffer.append(line)

                text = "\n".join(buffer)
                pipe_count = text.count(self._sep)

                if pipe_count == expected_pipes:
                    # Perfect match — complete record
                    yield "good", text.split(self._sep)
                    buffer = []

                elif pipe_count > expected_pipes:
                    # More pipes than expected — ambiguous / bad
                    logger.debug(
                        "BAD record ending at line %d: "
                        "found %d pipes, expected %d",
                        file_line, pipe_count, expected_pipes,
                    )
                    yield "bad", text
                    buffer = []

                elif len(buffer) >= self._max_cont:
                    # Continuation limit exceeded
                    logger.warning(
                        "BAD record ending at line %d: "
                        "exceeded max_continuation_lines=%d",
                        file_line, self._max_cont,
                    )
                    yield "bad", text
                    buffer = []
                # else: continue accumulating

        # Flush any trailing partial record
        if buffer:
            remainder = "\n".join(buffer)
            if remainder.strip():
                logger.warning(
                    "Incomplete record at end of file (last line ~%d): %s…",
                    file_line, remainder[:80],
                )
                yield "bad", remainder

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def count_records(self, filepath: Path) -> Tuple[int, int]:
        """Scan the file and return (good_count, bad_count) without storing data."""
        good = bad = 0
        for status, _ in self.parse(filepath):
            if status == "good":
                good += 1
            else:
                bad += 1
        return good, bad
