"""
Oracle connection-pool manager built on python-oracledb (thin mode by default).
All modules acquire connections via the get_connection() context manager.
"""

import logging
from contextlib import contextmanager
from typing import Any, List, Optional

import oracledb

from .config_manager import ConfigManager

logger = logging.getLogger("migration.db")


class DBError(Exception):
    pass


class DBManager:
    def __init__(self, config: ConfigManager):
        self._config = config
        self._pool: Optional[oracledb.ConnectionPool] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def initialize(self):
        """Create the connection pool. Call once at startup."""
        cfg = self._config
        try:
            dsn = f"{cfg.db_host}:{cfg.db_port}/{cfg.db_service_name}"
            self._pool = oracledb.create_pool(
                user=cfg.db_username,
                password=cfg.db_password,
                dsn=dsn,
                min=cfg.pool_min,
                max=cfg.pool_max,
                increment=cfg.pool_increment,
                timeout=cfg.pool_timeout,
                wait_timeout=cfg.pool_wait_timeout * 1000,  # milliseconds
                getmode=oracledb.POOL_GETMODE_WAIT,
            )
            logger.info(
                "Connection pool ready — %s (min=%d max=%d)",
                dsn, cfg.pool_min, cfg.pool_max,
            )
        except oracledb.Error as exc:
            raise DBError(f"Failed to create connection pool: {exc}") from exc

    def close(self):
        """Close the connection pool gracefully."""
        if self._pool:
            self._pool.close()
            self._pool = None
            logger.info("Connection pool closed")

    # ------------------------------------------------------------------
    # Connection acquisition
    # ------------------------------------------------------------------

    @contextmanager
    def get_connection(self):
        """
        Yield an Oracle connection from the pool.
        Rolls back and re-raises on any oracledb.Error.
        """
        if self._pool is None:
            raise DBError("Connection pool not initialised — call initialize() first.")
        conn = None
        try:
            conn = self._pool.acquire()
            conn.autocommit = False
            yield conn
        except oracledb.Error as exc:
            if conn:
                try:
                    conn.rollback()
                except Exception:
                    pass
            raise DBError(f"Database error: {exc}") from exc
        finally:
            if conn:
                try:
                    self._pool.release(conn)
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def execute_ddl(self, sql: str, conn=None):
        """Execute a DDL statement, using an externally supplied connection if given."""
        def _run(c):
            cur = c.cursor()
            try:
                cur.execute(sql)
                logger.debug("DDL: %s", sql[:120])
            finally:
                cur.close()

        if conn:
            _run(conn)
        else:
            with self.get_connection() as c:
                _run(c)

    def table_exists(self, table_name: str, conn=None) -> bool:
        sql = "SELECT COUNT(*) FROM user_tables WHERE table_name = :1"
        val = self.execute_scalar(sql, [table_name.upper()], conn)
        return bool(val)

    def execute_scalar(self, sql: str, params: Optional[List] = None, conn=None) -> Any:
        params = params or []

        def _run(c):
            cur = c.cursor()
            try:
                cur.execute(sql, params)
                row = cur.fetchone()
                return row[0] if row else None
            finally:
                cur.close()

        if conn:
            return _run(conn)
        with self.get_connection() as c:
            return _run(c)

    def execute_query(self, sql: str, params: Optional[List] = None, conn=None) -> List:
        params = params or []

        def _run(c):
            cur = c.cursor()
            try:
                cur.execute(sql, params)
                return cur.fetchall()
            finally:
                cur.close()

        if conn:
            return _run(conn)
        with self.get_connection() as c:
            return _run(c)

    def execute_dml(self, sql: str, params: Optional[List] = None, conn=None) -> int:
        """Execute an INSERT/UPDATE/DELETE, return rowcount. Does NOT commit."""
        params = params or []

        def _run(c):
            cur = c.cursor()
            try:
                cur.execute(sql, params)
                return cur.rowcount
            finally:
                cur.close()

        if conn:
            return _run(conn)
        with self.get_connection() as c:
            return _run(c)
