"""
Maps a raw file stem to a canonical category (= Oracle table name suffix).

Resolution order
----------------
1. Exact match in [file_mappings] config section         → use mapped value
2. Normalise abbreviations, then exact match in mappings → use mapped value
3. Normalise abbreviations only (no explicit mapping)    → use normalised stem
4. Fuzzy similarity against a registered catalog         → use best match
   (only when fuzzy_threshold > 0 and a catalog exists)
5. Fall back to the original file stem as-is

All comparisons are case-insensitive.  The returned canonical name is
lower-case; table_manager will upper-case it when building the table name.

Abbreviation normalisation
--------------------------
The ABBREV_MAP translates each abbreviated token to its canonical form.
Direction: abbreviation → full word  (so "cust" → "customer" is the
canonical form used for matching, not the other way around).
You can flip the direction by swapping keys/values — just be consistent
across all file names in every instance folder.

Fuzzy matching
--------------
Uses difflib.SequenceMatcher (stdlib, no extra dependency).
Only kicks in when:
  * fuzzy_threshold in config  > 0  (default 0 = disabled)
  * at least one category has been registered via register()
"""

import difflib
import logging
import re
from typing import Dict, Optional

from .config_manager import ConfigManager

logger = logging.getLogger("migration.mapper")

# ---------------------------------------------------------------------------
# Abbreviation dictionary
# Token-level: each _token_ in the stem is matched against these keys.
# Add / remove entries to suit your data.
# ---------------------------------------------------------------------------
ABBREV_MAP: Dict[str, str] = {
    # Abbreviation  →  canonical form
    "cust":    "customer",
    "addr":    "address",
    "ref":     "reference",
    "txn":     "transaction",
    "trans":   "transaction",
    "acct":    "account",
    "acc":     "account",
    "prod":    "product",
    "org":     "organisation",
    "dept":    "department",
    "emp":     "employee",
    "mgr":     "manager",
    "cfg":     "config",
    "conf":    "config",
    "info":    "information",
    "amt":     "amount",
    "qty":     "quantity",
    "num":     "number",
    "no":      "number",
    "dt":      "date",
    "ts":      "timestamp",
    "desc":    "description",
    "cd":      "code",
    "typ":     "type",
    "stat":    "status",
    "msg":     "message",
    "err":     "error",
    "usr":     "user",
    "grp":     "group",
    "seq":     "sequence",
    "pri":     "priority",
}


class CategoryMapper:
    def __init__(self, config: ConfigManager):
        self._config   = config
        # Explicit mappings from [file_mappings] section (lower → lower)
        self._explicit = self._load_explicit()
        # Catalog of known canonical categories (populated at runtime)
        self._catalog: set = set()
        # Threshold for fuzzy matching (0 = disabled)
        try:
            self._threshold = config._cfg.getfloat(
                "file_mappings", "fuzzy_threshold", fallback=0.0
            )
        except Exception:
            self._threshold = 0.0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def register(self, canonical: str):
        """
        Add a known canonical category to the fuzzy-match catalog.
        Call this for every category that has already been seen / mapped.
        """
        self._catalog.add(canonical.lower())

    def map(self, file_stem: str) -> str:
        """
        Return the canonical category name for *file_stem*.
        Always returns a non-empty lower-case string.
        """
        raw = file_stem.strip().lower()

        # 1. Exact explicit match
        if raw in self._explicit:
            result = self._explicit[raw]
            logger.debug("Mapping '%s' → '%s'  (explicit)", raw, result)
            return result

        # 2. Normalise, then try explicit match again
        normalised = self._normalise(raw)
        if normalised in self._explicit:
            result = self._explicit[normalised]
            logger.debug("Mapping '%s' → '%s'  (normalised→explicit)", raw, result)
            return result

        # 3. Normalised form only (no explicit override)
        if normalised != raw:
            logger.debug("Mapping '%s' → '%s'  (normalised)", raw, normalised)

        # 4. Fuzzy against catalog
        if self._threshold > 0 and self._catalog:
            best, score = self._fuzzy(normalised)
            if best and score >= self._threshold:
                logger.info(
                    "Mapping '%s' → '%s'  (fuzzy score=%.2f)", raw, best, score
                )
                return best
            elif best:
                logger.debug(
                    "Fuzzy candidate '%s' for '%s' rejected (score=%.2f < threshold=%.2f)",
                    best, raw, score, self._threshold,
                )

        # 5. Fall back: use normalised (or original) stem
        return normalised

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _load_explicit(self) -> Dict[str, str]:
        """Read [file_mappings] from config.ini into a lower→lower dict."""
        mappings: Dict[str, str] = {}
        section = "file_mappings"
        if not self._config._cfg.has_section(section):
            return mappings
        for key, value in self._config._cfg.items(section):
            if key == "fuzzy_threshold":
                continue
            k = key.strip().lower()
            v = value.strip().lower()
            if k and v:
                mappings[k] = v
                logger.debug("Explicit file mapping: '%s' → '%s'", k, v)
        return mappings

    @staticmethod
    def _normalise(stem: str) -> str:
        """
        Split the stem on underscores, expand each token via ABBREV_MAP,
        then rejoin.  Result is lower-case.
        """
        tokens = re.split(r"[_\-\s]+", stem.lower())
        expanded = [ABBREV_MAP.get(t, t) for t in tokens if t]
        return "_".join(expanded)

    def _fuzzy(self, normalised: str) -> tuple:
        """Return (best_match, score) from the catalog, or (None, 0)."""
        if not self._catalog:
            return None, 0.0
        scores = {
            cat: difflib.SequenceMatcher(None, normalised, cat).ratio()
            for cat in self._catalog
        }
        best = max(scores, key=scores.__getitem__)
        return best, scores[best]

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------

    def dump_mappings(self):
        """Log the full explicit mapping table (useful at startup)."""
        if self._explicit:
            logger.info("File → category explicit mappings:")
            for k, v in sorted(self._explicit.items()):
                logger.info("  %-30s → %s", k, v)
        else:
            logger.info("No explicit file mappings configured.")
