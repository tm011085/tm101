"""
Main orchestrator: discovers instances and files, streams records through
the parser, bulk-inserts into Oracle, tracks progress, and handles resume.

Resume strategy
---------------
If a previous load for the same file exists:
  * COMPLETED  → skip (unless force_reload=true)
  * FAILED / IN_PROGRESS → delete rows with that LOAD_ID from the target table,
                           then reload the entire file from scratch.

Bulk insertion
--------------
Uses cursor.executemany() with batcherrors=True so individual row failures
are captured in the bad-records file without aborting the batch.
For CLOB columns, cursor.setinputsizes() is called before each executemany.

Commit cadence
--------------
A commit is issued:
  1. Every  commit_interval  successfully inserted rows, AND
  2. Every 30 s (together with a progress-table update).
The two triggers are intentionally independent.
"""

import logging
import time
from pathlib import Path
from typing import List, Optional, Set, Tuple

import oracledb

from .category_mapper import CategoryMapper
from .config_manager import ConfigManager
from .db_manager import DBManager
from .file_parser import FileParser
from .progress_tracker import ProgressTracker
from .reconciliation import ReconciliationManager
from .table_manager import TableManager

logger = logging.getLogger("migration.loader")

_PROGRESS_LOG_INTERVAL = 30  # seconds between progress log lines


class LoadError(Exception):
    pass


class DataLoader:
    def __init__(
        self,
        config: ConfigManager,
        db: DBManager,
        table_mgr: TableManager,
        progress: ProgressTracker,
        recon: ReconciliationManager,
    ):
        self._config    = config
        self._db        = db
        self._table_mgr = table_mgr
        self._progress  = progress
        self._recon     = recon
        self._mapper    = CategoryMapper(config)
        self._parser    = FileParser(
            separator=config.separator,
            encoding=config.encoding,
            max_continuation_lines=config.max_continuation_lines,
        )

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def discover_instances(self) -> List[Path]:
        base = self._config.base_directory
        if not base.exists():
            raise LoadError(f"Base directory not found: {base}")
        dirs = sorted(d for d in base.iterdir() if d.is_dir())
        logger.info("Found %d instance(s) under %s", len(dirs), base)
        return dirs

    def discover_files(self, instance_dir: Path) -> List[Tuple[str, Path]]:
        """
        Return [(canonical_category, filepath), …] for every data file.

        The file stem is resolved to a canonical category via CategoryMapper:
          1. Explicit mapping in [file_mappings] config section
          2. Abbreviation normalisation  (cust→customer, addr→address, …)
          3. Fuzzy similarity against already-seen categories (if threshold > 0)
          4. Original stem as-is

        Files that map to the same canonical category are loaded into the
        same Oracle table regardless of which instance folder they come from.
        """
        files  = sorted(instance_dir.glob(self._config.file_pattern))
        result = []
        for f in files:
            canonical = self._mapper.map(f.stem)
            # Register so fuzzy matcher can compare future stems against it
            self._mapper.register(canonical)
            if canonical != f.stem.lower():
                logger.info(
                    "Instance %s: '%s' → category '%s'",
                    instance_dir.name, f.stem, canonical,
                )
            result.append((canonical, f))

        logger.info("Instance %s: %d file(s)", instance_dir.name, len(result))
        return result

    # ------------------------------------------------------------------
    # Top-level entry points
    # ------------------------------------------------------------------

    def load_all(self) -> dict:
        """Process every instance and every file. Returns summary counts."""
        self._mapper.dump_mappings()
        instances = self.discover_instances()
        summary = {"total": 0, "success": 0, "failed": 0, "skipped": 0}

        for inst_dir in instances:
            for category, filepath in self.discover_files(inst_dir):
                summary["total"] += 1
                try:
                    outcome = self.load_file(inst_dir.name, category, filepath)
                    summary[outcome] += 1
                except Exception as exc:
                    summary["failed"] += 1
                    logger.error(
                        "FAILED %s/%s: %s", inst_dir.name, category, exc,
                        exc_info=True,
                    )

        logger.info(
            "Migration complete — total=%d success=%d failed=%d skipped=%d",
            summary["total"], summary["success"],
            summary["failed"], summary["skipped"],
        )
        return summary

    def load_file(self, instance_name: str, category: str, filepath: Path) -> str:
        """
        Load one file.  Returns 'success', 'skipped', or raises on fatal error.
        """
        table_name    = self._config.get_table_name(category)
        file_path_str = str(filepath)

        with self._db.get_connection() as conn:
            existing = self._progress.get_file_status(file_path_str, conn)

            if existing and existing["status"] == "COMPLETED" and not self._config.force_reload:
                logger.info("Skipping %s/%s (COMPLETED)", instance_name, category)
                self._recon.record_skipped(
                    instance_name=instance_name,
                    category=category,
                    file_path=file_path_str,
                    file_name=filepath.name,
                    target_table=table_name,
                    conn=conn,
                )
                return "skipped"

            if existing and existing["status"] in ("FAILED", "IN_PROGRESS", "COMPLETED"):
                logger.info(
                    "Previous load found (status=%s) — cleaning up load_id=%d",
                    existing["status"], existing["load_id"],
                )
                self._cleanup(table_name, existing["load_id"], conn)

            # Read headers and ensure table exists
            try:
                headers = self._parser.read_headers(filepath)
            except Exception as exc:
                raise LoadError(f"Cannot read headers from {filepath}: {exc}") from exc

            data_cols, clob_set = self._table_mgr.get_or_create_table(
                table_name, headers, conn
            )
            conn.commit()

            load_id = self._progress.start_load(
                instance_name, category, file_path_str, table_name, conn
            )

        # Stream-load (uses its own pooled connection internally)
        try:
            loaded, bad = self._stream_load(
                instance_name=instance_name,
                category=category,
                filepath=filepath,
                table_name=table_name,
                data_cols=data_cols,
                clob_set=clob_set,
                load_id=load_id,
                file_path_str=file_path_str,
            )
        except Exception as exc:
            with self._db.get_connection() as conn:
                self._progress.fail_load(load_id, str(exc), conn)
            raise

        source_count = loaded + bad
        with self._db.get_connection() as conn:
            self._progress.complete_load(load_id, loaded, bad, source_count, conn)
            self._recon.record(
                load_id=load_id,
                instance_name=instance_name,
                category=category,
                file_path=file_path_str,
                file_name=filepath.name,
                target_table=table_name,
                source_count=source_count,
                loaded_count=loaded,
                bad_count=bad,
                conn=conn,
            )

        return "success"

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def _cleanup(self, table_name: str, load_id: int, conn):
        """Delete all rows written by a previous load attempt."""
        if not self._db.table_exists(table_name, conn):
            return
        load_id_col = self._config.audit_load_id_col
        sql = f"DELETE FROM {table_name} WHERE {load_id_col} = :1"
        cur = conn.cursor()
        try:
            cur.execute(sql, [load_id])
            deleted = cur.rowcount
            conn.commit()
            if deleted:
                logger.info("Deleted %d row(s) from previous load_id=%d", deleted, load_id)
        finally:
            cur.close()

    # ------------------------------------------------------------------
    # Core streaming load
    # ------------------------------------------------------------------

    def _stream_load(
        self,
        *,
        instance_name: str,
        category: str,
        filepath: Path,
        table_name: str,
        data_cols: List[str],
        clob_set: Set[str],
        load_id: int,
        file_path_str: str,
    ) -> Tuple[int, int]:
        """
        Parse *filepath* in a streaming fashion and bulk-insert into Oracle.
        Returns (loaded_count, bad_count).
        """
        cfg = self._config

        # Build INSERT statement
        #  Audit cols: INSTANCE_NAME, FILE_LOADED, LOAD_ID
        #  LOAD_TIMESTAMP uses column DEFAULT — not in the INSERT column list
        audit_cols = [cfg.audit_instance_col, cfg.audit_file_col, cfg.audit_load_id_col]
        all_cols   = data_cols + audit_cols
        ph         = ", ".join(f":{i + 1}" for i in range(len(all_cols)))
        insert_sql = f"INSERT INTO {table_name} ({', '.join(all_cols)}) VALUES ({ph})"

        # Pre-compute CLOB sizes list for setinputsizes (None = default inference)
        input_sizes = [
            oracledb.DB_TYPE_CLOB if col in clob_set else None
            for col in all_cols
        ]
        has_clob = bool(clob_set)

        # Bad-record file
        bad_dir  = cfg.bad_records_directory
        bad_dir.mkdir(parents=True, exist_ok=True)
        bad_file = bad_dir / f"{instance_name}_{category}_{load_id}_bad.txt"

        loaded     = 0
        bad        = 0
        total_lines = 0
        batch: List[tuple] = []
        t_start    = time.monotonic()
        t_last_log = time.monotonic()

        def flush(conn, batch_rows: List[tuple]) -> int:
            """Bulk-insert *batch_rows*; return number successfully inserted."""
            if not batch_rows:
                return 0
            cur = conn.cursor()
            try:
                if has_clob:
                    cur.setinputsizes(*input_sizes)
                cur.executemany(insert_sql, batch_rows, batcherrors=True)
                errors = cur.getbatcherrors()
                if errors:
                    for err in errors:
                        msg = f"INSERT_ERROR|row_offset={err.offset}|{err.message}\n"
                        bad_file.open("a", encoding="utf-8").write(msg)
                        logger.debug("Insert error offset %d: %s", err.offset, err.message)
                return len(batch_rows) - len(errors)
            finally:
                cur.close()

        with open(bad_file, "a", encoding="utf-8") as bad_out:
            with self._db.get_connection() as conn:
                for status, data in self._parser.parse(filepath):
                    total_lines += 1

                    if status == "bad":
                        bad += 1
                        bad_out.write(f"PARSE_ERROR\n{data}\n---END---\n\n")
                        continue

                    fields = list(data)

                    # Align field count to data_cols
                    if len(fields) < len(data_cols):
                        fields += [""] * (len(data_cols) - len(fields))
                    elif len(fields) > len(data_cols):
                        fields = fields[: len(data_cols)]

                    # Convert empty strings to None (Oracle NULL)
                    row = tuple(v.strip() or None for v in fields)

                    # Append audit values
                    row = row + (instance_name, file_path_str, load_id)
                    batch.append(row)

                    if len(batch) >= cfg.batch_size:
                        n = flush(conn, batch)
                        loaded += n
                        batch = []

                        now = time.monotonic()
                        elapsed = now - t_start or 0.001

                        # Commit every commit_interval records
                        if loaded % cfg.commit_interval < cfg.batch_size:
                            self._progress.update_progress(
                                load_id, loaded, bad, total_lines, conn
                            )
                            conn.commit()
                            t_last_log = now

                        # Log progress every 30 s
                        elif now - t_last_log >= _PROGRESS_LOG_INTERVAL:
                            self._progress.update_progress(
                                load_id, loaded, bad, total_lines, conn
                            )
                            conn.commit()
                            rate = loaded / elapsed
                            logger.info(
                                "Progress %s/%s: %s loaded  %s bad  %.0f rec/s",
                                instance_name, category,
                                f"{loaded:,}", f"{bad:,}", rate,
                            )
                            t_last_log = now

                # Flush remainder
                if batch:
                    loaded += flush(conn, batch)
                self._progress.update_progress(load_id, loaded, bad, total_lines, conn)
                conn.commit()

        # Remove the bad file if nothing was written
        if bad_file.exists() and bad_file.stat().st_size == 0:
            bad_file.unlink()

        elapsed = (time.monotonic() - t_start) or 0.001
        logger.info(
            "Finished %s/%s — loaded=%s bad=%s  %.1f s  (%.0f rec/s)",
            instance_name, category,
            f"{loaded:,}", f"{bad:,}",
            elapsed, loaded / elapsed,
        )
        return loaded, bad
