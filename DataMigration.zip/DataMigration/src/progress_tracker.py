"""
Tracks every file-load attempt in MIG_LOAD_PROGRESS.

Status lifecycle
----------------
  IN_PROGRESS  →  COMPLETED  (happy path)
  IN_PROGRESS  →  FAILED     (exception or interrupt)
  FAILED / IN_PROGRESS  →  cleaned up and re-loaded on next run
  COMPLETED            →  skipped (unless force_reload=true)

On startup the caller should invoke reset_stale_loads() which marks any
leftover IN_PROGRESS rows (from a crashed previous session) as FAILED.
"""

import logging
from typing import Dict, Optional

import oracledb

from .config_manager import ConfigManager
from .db_manager import DBManager

logger = logging.getLogger("migration.progress")


class ProgressTracker:
    def __init__(self, config: ConfigManager, db: DBManager):
        self._config = config
        self._db     = db
        self._table  = config.progress_table

    # ------------------------------------------------------------------
    # DDL
    # ------------------------------------------------------------------

    def create_table(self, conn=None):
        if self._db.table_exists(self._table, conn):
            return
        ddl = f"""
        CREATE TABLE {self._table} (
            LOAD_ID         NUMBER         GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            INSTANCE_NAME   VARCHAR2(500)  NOT NULL,
            CATEGORY        VARCHAR2(200)  NOT NULL,
            FILE_PATH       VARCHAR2(4000) NOT NULL,
            FILE_NAME       VARCHAR2(500)  NOT NULL,
            TARGET_TABLE    VARCHAR2(200),
            STATUS          VARCHAR2(50)   NOT NULL,
            TOTAL_LINES     NUMBER         DEFAULT 0,
            RECORDS_LOADED  NUMBER         DEFAULT 0,
            BAD_RECORDS     NUMBER         DEFAULT 0,
            START_TIME      TIMESTAMP,
            END_TIME        TIMESTAMP,
            LAST_UPDATED    TIMESTAMP      DEFAULT SYSTIMESTAMP,
            ERROR_MESSAGE   VARCHAR2(4000)
        )"""
        self._db.execute_ddl(ddl.strip(), conn)

        # Index for fast lookup by file path
        idx_ddl = (
            f"CREATE INDEX IDX_{self._table[:20]}_FP "
            f"ON {self._table} (FILE_PATH)"
        )
        try:
            self._db.execute_ddl(idx_ddl, conn)
        except Exception as exc:
            logger.warning("Could not create index on %s: %s", self._table, exc)

        logger.info("Created progress table: %s", self._table)

    # ------------------------------------------------------------------
    # State mutations
    # ------------------------------------------------------------------

    def start_load(
        self,
        instance_name: str,
        category: str,
        file_path: str,
        target_table: str,
        conn,
    ) -> int:
        """Insert an IN_PROGRESS row and return the generated LOAD_ID."""
        file_name = file_path.replace("\\", "/").rsplit("/", 1)[-1]
        sql = f"""
        INSERT INTO {self._table}
            (INSTANCE_NAME, CATEGORY, FILE_PATH, FILE_NAME, TARGET_TABLE,
             STATUS, START_TIME, LAST_UPDATED)
        VALUES
            (:1, :2, :3, :4, :5, 'IN_PROGRESS', SYSTIMESTAMP, SYSTIMESTAMP)
        RETURNING LOAD_ID INTO :6
        """
        cur = conn.cursor()
        try:
            out_var = cur.var(int)
            cur.execute(sql, [instance_name, category, file_path, file_name,
                               target_table, out_var])
            load_id = int(out_var.getvalue()[0])
            conn.commit()
            logger.info(
                "Load %d started: %s/%s → %s",
                load_id, instance_name, category, target_table,
            )
            return load_id
        finally:
            cur.close()

    def update_progress(
        self,
        load_id: int,
        records_loaded: int,
        bad_records: int,
        total_lines: int,
        conn,
    ):
        """Update counters. Does NOT commit — caller controls the transaction."""
        sql = f"""
        UPDATE {self._table}
        SET RECORDS_LOADED = :1,
            BAD_RECORDS    = :2,
            TOTAL_LINES    = :3,
            LAST_UPDATED   = SYSTIMESTAMP
        WHERE LOAD_ID = :4
        """
        cur = conn.cursor()
        try:
            cur.execute(sql, [records_loaded, bad_records, total_lines, load_id])
        finally:
            cur.close()

    def complete_load(
        self,
        load_id: int,
        records_loaded: int,
        bad_records: int,
        total_lines: int,
        conn,
    ):
        """Mark a load COMPLETED and commit."""
        sql = f"""
        UPDATE {self._table}
        SET STATUS          = 'COMPLETED',
            RECORDS_LOADED  = :1,
            BAD_RECORDS     = :2,
            TOTAL_LINES     = :3,
            END_TIME        = SYSTIMESTAMP,
            LAST_UPDATED    = SYSTIMESTAMP,
            ERROR_MESSAGE   = NULL
        WHERE LOAD_ID = :4
        """
        cur = conn.cursor()
        try:
            cur.execute(sql, [records_loaded, bad_records, total_lines, load_id])
            conn.commit()
        finally:
            cur.close()
        logger.info(
            "Load %d COMPLETED — loaded=%d  bad=%d  total_lines=%d",
            load_id, records_loaded, bad_records, total_lines,
        )

    def fail_load(self, load_id: int, error_message: str, conn):
        """Mark a load FAILED and commit."""
        sql = f"""
        UPDATE {self._table}
        SET STATUS        = 'FAILED',
            END_TIME      = SYSTIMESTAMP,
            LAST_UPDATED  = SYSTIMESTAMP,
            ERROR_MESSAGE = :1
        WHERE LOAD_ID = :2
        """
        cur = conn.cursor()
        try:
            cur.execute(sql, [str(error_message)[:4000], load_id])
            conn.commit()
        finally:
            cur.close()
        logger.error("Load %d FAILED: %s", load_id, str(error_message)[:200])

    def reset_stale_loads(self, conn):
        """
        Any row still IN_PROGRESS at startup was left by a crashed session.
        Mark them FAILED so they will be retried.
        """
        sql = f"""
        UPDATE {self._table}
        SET STATUS        = 'FAILED',
            ERROR_MESSAGE = 'Reset: process was interrupted',
            LAST_UPDATED  = SYSTIMESTAMP
        WHERE STATUS = 'IN_PROGRESS'
        """
        cur = conn.cursor()
        try:
            cur.execute(sql)
            n = cur.rowcount
            conn.commit()
            if n:
                logger.warning("Reset %d stale IN_PROGRESS load(s) to FAILED", n)
        finally:
            cur.close()

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_file_status(self, file_path: str, conn) -> Optional[Dict]:
        """Return the most recent load attempt for *file_path*, or None."""
        sql = f"""
        SELECT LOAD_ID, STATUS, RECORDS_LOADED, BAD_RECORDS
        FROM   {self._table}
        WHERE  FILE_PATH = :1
        ORDER BY LOAD_ID DESC
        FETCH FIRST 1 ROW ONLY
        """
        cur = conn.cursor()
        try:
            cur.execute(sql, [file_path])
            row = cur.fetchone()
        finally:
            cur.close()

        if row:
            return {
                "load_id":        row[0],
                "status":         row[1],
                "records_loaded": row[2],
                "bad_records":    row[3],
            }
        return None
