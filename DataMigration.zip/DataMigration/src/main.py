"""
Entry point for the Oracle Data Migration tool.

Usage
-----
  python -m src.main [OPTIONS]

  --config PATH           Path to config.ini  (default: config/config.ini)
  --instance NAME         Process only this instance folder
  --category NAME         Process only this file category (requires --instance)
  --force-reload          Reload files already marked COMPLETED
  --report-only           Print reconciliation report, no loading
  --validate-config       Validate config and exit
"""

import argparse
import logging
import logging.handlers
import sys
from pathlib import Path

# Allow   python -m src.main   from project root
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.config_manager import ConfigManager, ConfigError
from src.db_manager import DBManager, DBError
from src.data_loader import DataLoader, LoadError
from src.table_manager import TableManager
from src.progress_tracker import ProgressTracker
from src.reconciliation import ReconciliationManager


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def setup_logging(config: ConfigManager):
    log_dir = config.log_directory
    log_dir.mkdir(parents=True, exist_ok=True)

    handlers = {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "simple",
            "level": config.log_level,
            "stream": "ext://sys.stdout",
        },
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "formatter": "detailed",
            "level": config.log_level,
            "filename": str(log_dir / "migration.log"),
            "maxBytes": config.log_max_bytes,
            "backupCount": config.log_backup_count,
            "encoding": "utf-8",
        },
        "error_file": {
            "class": "logging.handlers.RotatingFileHandler",
            "formatter": "detailed",
            "level": "ERROR",
            "filename": str(log_dir / "migration_errors.log"),
            "maxBytes": config.log_max_bytes,
            "backupCount": config.log_backup_count,
            "encoding": "utf-8",
        },
    }

    logging.config.dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "detailed": {
                    "format": (
                        "%(asctime)s | %(name)-30s | %(levelname)-8s | "
                        "%(funcName)s:%(lineno)d | %(message)s"
                    ),
                    "datefmt": "%Y-%m-%d %H:%M:%S",
                },
                "simple": {
                    "format": "%(asctime)s | %(levelname)-8s | %(message)s",
                    "datefmt": "%Y-%m-%d %H:%M:%S",
                },
            },
            "handlers": handlers,
            "loggers": {
                "migration": {
                    "level": config.log_level,
                    "handlers": ["console", "file", "error_file"],
                    "propagate": False,
                },
            },
            "root": {"level": "WARNING", "handlers": ["console"]},
        }
    )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="migration",
        description="Oracle Data Migration Tool — pipe-delimited flat files → Oracle tables",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples
--------
  # Full migration (all instances, all categories)
  python -m src.main

  # Custom config location
  python -m src.main --config /etc/migration/prod.ini

  # Single instance
  python -m src.main --instance instance1

  # Single file category within one instance
  python -m src.main --instance instance1 --category case

  # Force-reload already completed files
  python -m src.main --force-reload

  # Print reconciliation report without loading anything
  python -m src.main --report-only

  # Validate configuration and exit
  python -m src.main --validate-config
""",
    )
    p.add_argument("--config",          type=Path,  default=None,
                   help="Path to config.ini")
    p.add_argument("--instance",        type=str,   default=None,
                   help="Load only this instance folder name")
    p.add_argument("--category",        type=str,   default=None,
                   help="Load only this category (requires --instance)")
    p.add_argument("--force-reload",    action="store_true",
                   help="Reload files already marked COMPLETED")
    p.add_argument("--report-only",     action="store_true",
                   help="Print reconciliation report and exit")
    p.add_argument("--validate-config", action="store_true",
                   help="Validate configuration then exit")
    return p


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    args = _build_parser().parse_args()

    # -- Config --------------------------------------------------------------
    try:
        config = ConfigManager(args.config)
    except ConfigError as exc:
        print(f"[CONFIG ERROR] {exc}", file=sys.stderr)
        sys.exit(1)

    if args.force_reload:
        config.force_reload = True

    # -- Logging -------------------------------------------------------------
    # Import here so dictConfig is in scope
    import logging.config  # noqa: F401 (already imported at top via logging.config)
    setup_logging(config)
    logger = logging.getLogger("migration.main")

    if args.validate_config:
        logger.info("Configuration OK")
        sys.exit(0)

    # -- Database ------------------------------------------------------------
    db = DBManager(config)
    try:
        db.initialize()
    except DBError as exc:
        logger.critical("Database init failed: %s", exc)
        sys.exit(1)

    # -- Components ----------------------------------------------------------
    table_mgr = TableManager(config, db)
    progress  = ProgressTracker(config, db)
    recon     = ReconciliationManager(config, db)

    try:
        # Ensure metadata tables exist
        with db.get_connection() as conn:
            progress.create_table(conn)
            recon.create_table(conn)
            conn.commit()
            # Mark crashed loads as FAILED so they'll be retried
            progress.reset_stale_loads(conn)

        if args.report_only:
            recon.print_summary()
            return

        loader = DataLoader(config, db, table_mgr, progress, recon)

        if args.instance:
            inst_dir = config.base_directory / args.instance
            if not inst_dir.exists():
                logger.error("Instance directory not found: %s", inst_dir)
                sys.exit(1)

            files = loader.discover_files(inst_dir)
            if args.category:
                files = [(cat, fp) for cat, fp in files
                         if cat == args.category.lower()]
                if not files:
                    logger.error(
                        "No files found for category '%s' in instance '%s'",
                        args.category, args.instance,
                    )
                    sys.exit(1)

            for category, filepath in files:
                try:
                    loader.load_file(args.instance, category, filepath)
                except (LoadError, Exception) as exc:
                    logger.error("Failed %s/%s: %s", args.instance, category, exc)
        else:
            loader.load_all()

        recon.print_summary()

    except KeyboardInterrupt:
        logger.warning("Interrupted by user (Ctrl-C)")
        sys.exit(130)

    except Exception as exc:
        logger.critical("Unhandled error: %s", exc, exc_info=True)
        sys.exit(1)

    finally:
        db.close()


if __name__ == "__main__":
    main()
